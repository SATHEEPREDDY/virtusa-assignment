import java.util.*;
public class NumberToWord {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		  int n=0;
		    Scanner scanf = new Scanner(System.in);
		    System.out.println("Enter an integer number: ");
		    n = scanf.nextInt();
		    
		    
		    if(n <= 0) {                  
		      System.out.println("Enter numbers greater than 0");
		   }
		   else
		   {
			   NumberToWord a = new NumberToWord();
			   NumberToWord.pw((n/1000000000)," Hundred");
			   NumberToWord.pw((n/10000000)%100," crore");
			   NumberToWord.pw(((n/100000)%100)," lakh");
			   NumberToWord.pw(((n/1000)%100)," thousand");
			   NumberToWord.pw(((n/100)%10)," hundred");
			   NumberToWord.pw((n%100)," ");
		    }

	}
	
	
	
	
	public static void pw(int n,String ch)
	  {
		try{
		
	    String  one[]={" "," one"," two"," three"," four"," five"," six"," seven"," eight"," Nine"," ten"," eleven"," twelve"," thirteen"," fourteen","fifteen"," sixteen"," seventeen"," eighteen"," nineteen"};

	    String ten[]={" "," "," twenty"," thirty"," forty"," fifty"," sixty","seventy"," eighty"," ninety"};

	    if(n > 19) 
	    { 
	    	System.out.print(ten[n/10]+" "+one[n%10]);
	    } 
	    else {
	    	
	    	System.out.print(one[n]);
	    	
	    }
	    if(n > 0)System.out.print(ch);
	  
		}catch(Exception e)
		{
		     System.out.print(e.getMessage());	
		}
	  }	

}
